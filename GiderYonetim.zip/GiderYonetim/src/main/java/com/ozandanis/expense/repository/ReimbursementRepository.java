package com.ozandanis.expense.repository;

import com.ozandanis.expense.model.Reimbursement;
import com.ozandanis.expense.util.JdbcUtil;

import java.math.BigDecimal;
import java.sql.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class ReimbursementRepository {

    public Optional<Reimbursement> findById(int id) throws SQLException {
        String sql = "SELECT id, expense_id, reimbursed_amount, reimbursement_date FROM reimbursement WHERE id = ?";
        try (Connection conn = JdbcUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, id);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                return Optional.of(mapRow(rs));
            }
            return Optional.empty();
        }
    }

    public List<Reimbursement> findByExpenseId(int expenseId) throws SQLException {
        String sql = "SELECT id, expense_id, reimbursed_amount, reimbursement_date FROM reimbursement WHERE expense_id = ?";
        List<Reimbursement> list = new ArrayList<>();
        try (Connection conn = JdbcUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, expenseId);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                list.add(mapRow(rs));
            }
        }
        return list;
    }

    public void save(Reimbursement r) throws SQLException {
        String sql = "INSERT INTO reimbursement(expense_id, reimbursed_amount, reimbursement_date) VALUES(?, ?, ?)";
        try (Connection conn = JdbcUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            ps.setInt(1, r.getExpenseId());
            ps.setBigDecimal(2, r.getReimbursedAmount());
            ps.setDate(3, Date.valueOf(r.getReimbursementDate()));
            ps.executeUpdate();
            ResultSet keys = ps.getGeneratedKeys();
            if (keys.next()) {
                r.setId(keys.getInt(1));
            }
        }
    }

    public void deleteById(int id) throws SQLException {
        String sql = "DELETE FROM reimbursement WHERE id = ?";
        try (Connection conn = JdbcUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, id);
            ps.executeUpdate();
        }
    }

    private Reimbursement mapRow(ResultSet rs) throws SQLException {
        return new Reimbursement(
                rs.getInt("id"),
                rs.getInt("expense_id"),
                rs.getBigDecimal("reimbursed_amount"),
                rs.getDate("reimbursement_date").toLocalDate()
        );
    }
}
