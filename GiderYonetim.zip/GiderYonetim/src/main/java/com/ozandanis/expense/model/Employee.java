package com.ozandanis.expense.model;

public class Employee {
    private int id;
    private String name;
    private int unitId;
    private Integer managerId;

    public Employee() {}

    public Employee(int id, String name, int unitId, Integer managerId) {
        this.id = id;
        this.name = name;
        this.unitId = unitId;
        this.managerId = managerId;
    }

    public Employee(String name, int unitId, Integer managerId) {
        this.name = name;
        this.unitId = unitId;
        this.managerId = managerId;
    }

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public int getUnitId() { return unitId; }
    public void setUnitId(int unitId) { this.unitId = unitId; }
    public Integer getManagerId() { return managerId; }
    public void setManagerId(Integer managerId) { this.managerId = managerId; }

    @Override
    public String toString() {
        return "Employee{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", unitId=" + unitId +
                ", managerId=" + managerId +
                '}';
    }
}
