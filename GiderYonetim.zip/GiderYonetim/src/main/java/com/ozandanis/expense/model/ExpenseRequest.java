package com.ozandanis.expense.model;

import java.math.BigDecimal;
import java.time.LocalDate;

public class ExpenseRequest {
    private int id;
    private int employeeId;
    private int categoryId;
    private BigDecimal amount;
    private LocalDate date;
    private String status;
    private Integer correctedCategoryId;

    public ExpenseRequest() {}

    public ExpenseRequest(int id, int employeeId, int categoryId,
                          BigDecimal amount, LocalDate date,
                          String status, Integer correctedCategoryId) {
        this.id = id;
        this.employeeId = employeeId;
        this.categoryId = categoryId;
        this.amount = amount;
        this.date = date;
        this.status = status;
        this.correctedCategoryId = correctedCategoryId;
    }

    // getter/setter’lar
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    public int getEmployeeId() { return employeeId; }
    public void setEmployeeId(int employeeId) { this.employeeId = employeeId; }
    public int getCategoryId() { return categoryId; }
    public void setCategoryId(int categoryId) { this.categoryId = categoryId; }
    public BigDecimal getAmount() { return amount; }
    public void setAmount(BigDecimal amount) { this.amount = amount; }
    public LocalDate getDate() { return date; }
    public void setDate(LocalDate date) { this.date = date; }
    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
    public Integer getCorrectedCategoryId() { return correctedCategoryId; }
    public void setCorrectedCategoryId(Integer correctedCategoryId) { this.correctedCategoryId = correctedCategoryId; }

    @Override
    public String toString() {
        return "ExpenseRequest{" +
                "id=" + id +
                ", employeeId=" + employeeId +
                ", categoryId=" + categoryId +
                ", amount=" + amount +
                ", date=" + date +
                ", status='" + status + '\'' +
                ", correctedCategoryId=" + correctedCategoryId +
                '}';
    }
}
