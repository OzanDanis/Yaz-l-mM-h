package com.ozandanis.expense.repository;

import com.ozandanis.expense.model.ExpenseRequest;
import com.ozandanis.expense.util.JdbcUtil;

import java.math.BigDecimal;
import java.sql.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class ExpenseRequestRepository {

    public Optional<ExpenseRequest> findById(int id) throws SQLException {
        String sql = "SELECT id, employee_id, category_id, amount, date, status, corrected_category_id " +
                "FROM expense_request WHERE id = ?";
        try (Connection conn = JdbcUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, id);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                return Optional.of(mapRow(rs));
            }
            return Optional.empty();
        }
    }

    public List<ExpenseRequest> findByEmployeeId(int employeeId) throws SQLException {
        String sql = "SELECT id, employee_id, category_id, amount, date, status, corrected_category_id " +
                "FROM expense_request WHERE employee_id = ?";
        List<ExpenseRequest> list = new ArrayList<>();
        try (Connection conn = JdbcUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, employeeId);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                list.add(mapRow(rs));
            }
        }
        return list;
    }

    public void save(ExpenseRequest req) throws SQLException {
        String sql = "INSERT INTO expense_request(employee_id, category_id, amount, date, status, corrected_category_id) " +
                "VALUES(?, ?, ?, ?, ?, ?)";
        try (Connection conn = JdbcUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            ps.setInt(1, req.getEmployeeId());
            ps.setInt(2, req.getCategoryId());
            ps.setBigDecimal(3, req.getAmount());
            ps.setDate(4, Date.valueOf(req.getDate()));
            ps.setString(5, req.getStatus());
            if (req.getCorrectedCategoryId() != null) {
                ps.setInt(6, req.getCorrectedCategoryId());
            } else {
                ps.setNull(6, Types.INTEGER);
            }
            ps.executeUpdate();
            ResultSet keys = ps.getGeneratedKeys();
            if (keys.next()) {
                req.setId(keys.getInt(1));
            }
        }
    }

    public void updateStatus(int id, String status) throws SQLException {
        String sql = "UPDATE expense_request SET status = ? WHERE id = ?";
        try (Connection conn = JdbcUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, status);
            ps.setInt(2, id);
            ps.executeUpdate();
        }
    }

    public BigDecimal sumApprovedByUnit(int unitId) throws SQLException {
        String sql = "SELECT COALESCE(SUM(er.amount),0) AS total " +
                "FROM expense_request er " +
                "JOIN employee e ON er.employee_id = e.id " +
                "WHERE e.unit_id = ? AND er.status = 'APPROVED'";
        try (Connection conn = JdbcUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, unitId);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                return rs.getBigDecimal("total");
            }
            return BigDecimal.ZERO;
        }
    }

    private ExpenseRequest mapRow(ResultSet rs) throws SQLException {
        return new ExpenseRequest(
                rs.getInt("id"),
                rs.getInt("employee_id"),
                rs.getInt("category_id"),
                rs.getBigDecimal("amount"),
                rs.getDate("date").toLocalDate(),
                rs.getString("status"),
                (Integer) rs.getObject("corrected_category_id")
        );
    }

    public void deleteById(int id) throws SQLException {
        String sql = "DELETE FROM expense_request WHERE id = ?";
        try (Connection conn = JdbcUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, id);
            ps.executeUpdate();
        }
    }
    public void updateCorrectedCategory(int requestId, int newCategoryId) throws SQLException {
        String sql = "UPDATE expense_request SET corrected_category_id = ? WHERE id = ?";
        try (Connection conn = JdbcUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, newCategoryId);
            ps.setInt(2, requestId);
            ps.executeUpdate();
        }
    }
}
