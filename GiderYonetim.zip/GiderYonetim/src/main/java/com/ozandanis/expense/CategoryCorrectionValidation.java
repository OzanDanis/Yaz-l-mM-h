package com.ozandanis.expense;

import com.ozandanis.expense.model.*;
import com.ozandanis.expense.repository.*;
import com.ozandanis.expense.service.ExpenseRequestService;

import java.math.BigDecimal;
import java.time.LocalDate;

public class CategoryCorrectionValidation {
    public static void main(String[] args) {
        try {
            // Hazırlık: Unit, Employee, Category, Request
            Unit unit = new Unit("DüzeltmeTest", new BigDecimal("5000"), new BigDecimal("0"));
            new UnitRepository().save(unit);

            Employee emp = new Employee("Emre", unit.getId(), null);
            new EmployeeRepository().save(emp);

            ExpenseCategory oldCat = new ExpenseCategory("YanlışKalem");
            new ExpenseCategoryRepository().save(oldCat);
            ExpenseCategory correctCat = new ExpenseCategory("DoğruKalem");
            new ExpenseCategoryRepository().save(correctCat);

            ExpenseRequestService svc = new ExpenseRequestService();
            ExpenseRequest req = svc.createRequest(
                    emp.getId(),
                    oldCat.getId(),
                    new BigDecimal("100"),
                    LocalDate.now()
            );
            System.out.println("Önce: " + req);

            // Kategori düzeltmesi
            req = svc.correctCategory(req.getId(), correctCat.getId());
            System.out.println("Sonra: " + req);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
